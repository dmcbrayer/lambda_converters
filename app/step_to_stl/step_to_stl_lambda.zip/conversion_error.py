class ConversionError(Exception): pass
